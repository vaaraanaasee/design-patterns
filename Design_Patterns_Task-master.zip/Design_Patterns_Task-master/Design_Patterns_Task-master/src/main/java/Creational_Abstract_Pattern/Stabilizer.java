package Creational_Abstract_Pattern;

public interface Stabilizer
{
    public String instruction();
}
