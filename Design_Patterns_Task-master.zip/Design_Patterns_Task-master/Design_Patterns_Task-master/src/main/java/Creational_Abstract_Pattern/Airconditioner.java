package Creational_Abstract_Pattern;

public interface Airconditioner
{
    public Cooler_stab information();
}
