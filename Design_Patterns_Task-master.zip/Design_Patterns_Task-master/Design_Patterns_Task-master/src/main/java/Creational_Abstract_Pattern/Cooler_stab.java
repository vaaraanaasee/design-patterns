package Creational_Abstract_Pattern;

public class Cooler_stab implements Stabilizer {
    public String instruction()
    {
        return "It doesn't need stabilizer.";
    }
}
