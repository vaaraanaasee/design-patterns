package Behavioural_State_Pattern;

public interface Bank
{
    public void open();
    public void close();
}
