package Creational_Factory_Pattern;

public interface Shape {
    public String area(int size);
}
