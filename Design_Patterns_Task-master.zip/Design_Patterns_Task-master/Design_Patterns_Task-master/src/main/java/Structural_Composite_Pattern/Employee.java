package Structural_Composite_Pattern;

public interface Employee {
    public  int getId();
    public String getName();
    public double getSalary();
    public void print();
}
