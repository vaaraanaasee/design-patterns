package Structural_Adapter_Pattern;

public interface CreditCard
{
    public void giveBankDetails();
    public String getCreditCard();
}
